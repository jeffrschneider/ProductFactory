# The records this agent must leave

This is the contract. The agent leaves the following behind, on
every run.

- what the job did not have and did anyway — at `*/went-without.json`
- the signed job manifest of each delivery

An agent that leaves less than this does not do this job,
whatever else it does well.
