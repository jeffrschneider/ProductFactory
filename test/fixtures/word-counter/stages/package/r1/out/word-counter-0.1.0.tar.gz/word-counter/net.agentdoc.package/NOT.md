# Where this agent stops

Counting anything that is not a sentence of text. If multiple sentences or non-text content are provided, it stops and returns an error explaining that only a single sentence is accepted.
Processing binary files, images, or any media types other than plain text. It does not attempt to extract text from images or documents, and will immediately reject them.
Guessing the word count of an empty or missing input. It does not provide a zero or a default value when no text is handed over, but instead stops and says what this agent takes.
Accepting a credential value or a system address pasted into the text input. It reads the input strictly as a sentence to be counted and does not execute or connect to any provided address.
